// src/app/Components/T/MyClasses/ViewClass/Quiz/Create/page.tsx
"use client";

import React, { useState, useEffect, ChangeEvent, MouseEvent } from "react";

interface ClassCourse {
  className: string;
  course: string;
  teacherId: string;
}

export default function CreateQuiz() {
  const [classes, setClasses] = useState<ClassCourse[]>([]);
  const [selectedClass, setSelectedClass] = useState<ClassCourse | null>(null);
  const [teacherName, setTeacherName] = useState("");
  const [showInstructions, setShowInstructions] = useState(false);

  // Quiz fields (online only)
  const [quizTitle, setQuizTitle] = useState("");
  const [description, setDescription] = useState("");
  const [questionCount, setQuestionCount] = useState<number>(1);
  const [correctAnswers, setCorrectAnswers] = useState<string[]>(["A"]);
  const [totalMarks, setTotalMarks] = useState(0);
  const [deadline, setDeadline] = useState("");
  const [key, setKey] = useState("");
  const [timeLimit, setTimeLimit] = useState<number>(0);
  const [shortNote, setShortNote] = useState("");

  // Load classes
  useEffect(() => {
    const teacherId = localStorage.getItem("teacherId");
    if (!teacherId) return;
    fetch(`/api/Component/T/timetable?teacherId=${teacherId}`)
      .then(r => r.json())
      .then((data: ClassCourse[]) => {
        const uniq: ClassCourse[] = [];
        new Set(data.map(c => `${c.className}—${c.course}`)).forEach(k => {
          const [cn, co] = k.split("—");
          uniq.push({ className: cn, course: co, teacherId: data[0].teacherId });
        });
        setClasses(uniq);
      });
  }, []);

  // Load teacher name once class selected
  useEffect(() => {
    if (!selectedClass) return;
    fetch(
      `/api/Component/T/MyClasses/ViewClass/assignments/Select/create?teacherId=${selectedClass.teacherId}`
    )
      .then(r => r.json())
      .then(d => setTeacherName(`${d.firstName} ${d.lastName}`));
  }, [selectedClass]);

  // When questionCount changes, resize correctAnswers array
  useEffect(() => {
    setCorrectAnswers(prev => {
      const arr = [...prev];
      while (arr.length < questionCount) arr.push("A");
      if (arr.length > questionCount) arr.length = questionCount;
      return arr;
    });
  }, [questionCount]);
// derive class & rollNo inside useEffect
useEffect(() => {
  if (typeof window === "undefined") return;
  const classLevel = localStorage.getItem("classLevel");
  const classType  = localStorage.getItem("classType");
  const storedName = localStorage.getItem("className");
  const rollNo     = localStorage.getItem("rollNo");
  // … set these into state …
}, []);

  // ─── Submit handler ───────────────────────────────────────────────────────
 // inside src/app/Components/T/MyClasses/ViewClass/Quiz/Create/page.tsx

const handleSubmit = async (e: MouseEvent) => {
  e.preventDefault();

  // 1) Basic validation
  if (!quizTitle.trim()) {
    return alert("Quiz title is required");
  }
  if (!selectedClass) {
    return alert("Please select a class/course");
  }
  if (questionCount < 1 || questionCount > 50) {
    return alert("Question count must be between 1 and 50");
  }
  if (timeLimit < 1) {
    return alert("Please set a time limit (in minutes)");
  }

  // 2) Build FormData
  const teacherId = localStorage.getItem("teacherId")!;
  const fd = new FormData();
  fd.append("quizTitle", quizTitle);
  fd.append("description", description);
  fd.append("className", selectedClass.className);
  fd.append("course", selectedClass.course);
  fd.append("totalMarks", String(totalMarks));
  fd.append("deadline", deadline);
  fd.append("teacherId", teacherId);
  fd.append("key", key);
  fd.append("mode", "online");
  fd.append("questionCount", String(questionCount));
  fd.append("timeLimit", String(timeLimit));
  fd.append("shortNote", shortNote);

  // 3) Format and append correctAnswers
  const formattedAnswers = correctAnswers.map((ans, idx) => ({
    question: idx + 1,
    answer: ans,
  }));
  fd.append("correctAnswers", JSON.stringify(formattedAnswers));

  // 4) Send to server
  const res = await fetch(
    "/api/Component/T/MyClasses/ViewClass/Quiz/Create",
    { method: "POST", body: fd }
  );

  if (res.ok) {
    alert("Quiz created!");
    window.location.reload();
  } else {
    const err = await res.text();
    alert("Error: " + err);
  }
};

  if (!classes.length) return <p>Loading classes…</p>;
  if (!selectedClass) {
    return (
      <div className="p-6">
        <h2 className="text-2xl mb-4">Select Class/Course</h2>
        <div className="grid grid-cols-2 gap-4">
          {classes.map((c,i) => (
            <button
              key={i}
              onClick={() => setSelectedClass(c)}
              className="p-4 bg-blue-500 text-white rounded"
            >
              {c.className} — {c.course}
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6 bg-gray-50">
      <div className="max-w-3xl mx-auto bg-white p-6 rounded shadow">
        <h2 className="text-2xl font-bold mb-4">Create Quiz</h2>
        <p className="mb-4">Teacher: <strong>{teacherName}</strong></p>

        {/* Common fields */}
        <input
          type="text"
          placeholder="Quiz Title"
          className="w-full p-3 mb-4 border rounded"
          value={quizTitle}
          onChange={e => setQuizTitle(e.target.value)}
        />
        <textarea
          rows={8}
          placeholder="Enter MCQs text…"
          className="w-full p-3 mb-4 border rounded font-mono"
          value={description}
          onChange={e => setDescription(e.target.value)}
        />

        <div className="mb-4">
          <label className="block mb-1">Time Limit (minutes):</label>
          <input
            type="number"
            min={1}
            className="w-full p-3 border rounded"
            value={timeLimit}
            onChange={e => setTimeLimit(Number(e.target.value))}
          />
        </div>

        <div className="mb-4">
          <label className="block mb-1">Short Note (optional):</label>
          <textarea
            rows={2}
            className="w-full p-3 border rounded"
            value={shortNote}
            onChange={e => setShortNote(e.target.value)}
          />
        </div>

        <div className="mb-4">
          <label className="block mb-1">Total Marks:</label>
          <input
            type="number"
            min={0}
            className="w-full p-3 border rounded"
            value={totalMarks}
            onChange={e => setTotalMarks(Number(e.target.value))}
          />
        </div>

        <div className="mb-4">
          <label className="block mb-1">Deadline:</label>
          <input
            type="date"
            className="w-full p-3 border rounded"
            value={deadline}
            onChange={e => setDeadline(e.target.value)}
          />
        </div>

        <div className="mb-4">
          <label className="block mb-1">Key:</label>
          <input
            type="text"
            className="w-full p-3 border rounded"
            value={key}
            onChange={e => setKey(e.target.value)}
          />
        </div>

        <div className="mb-6">
          <label className="block mb-1">Number of Questions (1–50):</label>
          <input
            type="number"
            min={1}
            max={50}
            className="w-full p-3 border rounded"
            value={questionCount}
            onChange={e => setQuestionCount(Number(e.target.value))}
          />
        </div>

        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-2">Correct Answers</h3>
          <p className="text-sm mb-2">
            For each question 1…{questionCount}, choose the correct option.
          </p>
          <div className="grid grid-cols-2 gap-4">
            {Array.from({ length: questionCount }, (_, i) => (
              <div key={i} className="flex items-center space-x-2">
                <span>Q{i + 1}:</span>
                <select
                  className="p-2 border rounded"
                  value={correctAnswers[i]}
                  onChange={(e) => {
                    const ans = e.target.value as string;
                    setCorrectAnswers((prev) => {
                      const next = [...prev];
                      next[i] = ans;
                      return next;
                    });
                  }}
                >
                  {["A", "B", "C", "D", "E"].map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              </div>
            ))}
          </div>
        </div>

        {/* PUBLISH BUTTON */}
        <button
          onClick={handleSubmit}
          className="w-full py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
        >
          Publish Quiz
        </button>
      </div>
    </div>
  );
}
