import { NextResponse } from "next/server";
import mongoose from "mongoose";
import QuizModel from "@/models/Quiz";

const connectDB = async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGODB_URI!);
  }
};

export async function GET(req: Request) {
  try {
    await connectDB();
    const { searchParams } = new URL(req.url);
    const className = searchParams.get("className");
    const course    = searchParams.get("course");
    if (!className || !course) {
      return NextResponse.json(
        { error: "className and course are required" },
        { status: 400 }
      );
    }

    // Explicitly include quizFile.fileName (and omit the buffer)
    const quizzes = await QuizModel.find({ className, course })
      .sort({ deadline: 1 })
      .select([
        "quizTitle",
        "description",
        "totalMarks",
        "deadline",
        "quizFile.fileName",
      ])
      .lean();

    return NextResponse.json({ quizzes });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
